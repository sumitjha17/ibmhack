

package com.ibm.mobileappbuilder.storecatalog20150911132549;

import android.app.Application;
import ibmmobileappbuilder.injectors.ApplicationInjector;
import android.support.multidex.MultiDexApplication;
import ibmmobileappbuilder.analytics.injector.AnalyticsReporterInjector;
import ibmmobileappbuilder.cloudant.factory.CloudantDatabaseSyncerFactory;
import java.net.URI;


/**
 * You can use this as a global place to keep application-level resources
 * such as singletons, services, etc.
 */
public class MyApplication extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();
        ApplicationInjector.setApplicationContext(this);
        AnalyticsReporterInjector.analyticsReporter(this).init(this);
        //Syncing cloudant ds
        CloudantDatabaseSyncerFactory.instanceFor(
            "fashion",
            URI.create("https://e0a71e32-5f5c-41c8-a1ca-e7f2796da2a0-bluemix:d67b5882fac5645ff956554ef6d43fe2e604c97f83b438646fe01fd471dd79f7@e0a71e32-5f5c-41c8-a1ca-e7f2796da2a0-bluemix.cloudant.com/fashion")
        ).sync(null);
      }
}

