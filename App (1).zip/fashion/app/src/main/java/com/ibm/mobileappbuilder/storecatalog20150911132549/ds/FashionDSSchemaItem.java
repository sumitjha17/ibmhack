
package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;

import ibmmobileappbuilder.mvp.model.MutableIdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class FashionDSSchemaItem implements Parcelable, MutableIdentifiableBean {

    private transient String cloudantIdentifiableId;

    @SerializedName("welcome") public String welcome;

    @Override
    public void setIdentifiableId(String id) {
        this.cloudantIdentifiableId = id;
    }

    @Override
    public String getIdentifiableId() {
        return cloudantIdentifiableId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(cloudantIdentifiableId);
        dest.writeString(welcome);
    }

    public static final Creator<FashionDSSchemaItem> CREATOR = new Creator<FashionDSSchemaItem>() {
        @Override
        public FashionDSSchemaItem createFromParcel(Parcel in) {
            FashionDSSchemaItem item = new FashionDSSchemaItem();
            item.cloudantIdentifiableId = in.readString();

            item.welcome = in.readString();
            return item;
        }

        @Override
        public FashionDSSchemaItem[] newArray(int size) {
            return new FashionDSSchemaItem[size];
        }
    };
}


